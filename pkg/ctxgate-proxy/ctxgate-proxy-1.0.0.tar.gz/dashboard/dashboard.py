"""ctxgate-dashboard: Health monitoring + control center for the ctxgate-proxy ecosystem.

Monitors: PostgreSQL, vLLM, LM Studio, ctxgate-proxy, 4B worker.
Serves a single-page GUI on port 9201.
Starts independently (no ordering deps); polls service health asynchronously.

Control: the GUI buttons start / stop / hard-restart the proxy and worker.
Hard-restart = stop -> SIGKILL leftovers -> free the port (kill whatever
holds it) -> reset-failed -> fresh start -> verify health. Zero terminal.
"""
import asyncio
import json
import os
import re
import signal
import time
from typing import Optional

import httpx
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse

# --- Configuration ---
PORT = int(os.environ.get("CTXGATE_DASHBOARD_PORT", "9201"))
POLL_INTERVAL = float(os.environ.get("CTXGATE_DASHBOARD_POLL", "300.0"))

# Service endpoints to monitor
SERVICES = {
    "postgresql": {"type": "tcp", "host": "127.0.0.1", "port": 5432},
    "vllm": {"type": "http", "url": "http://127.0.0.1:29000/v1/models"},
    "lm_studio": {"type": "http", "url": "http://127.0.0.1:1234/v1/models"},
    "ctxgate_proxy": {"type": "http", "url": "http://127.0.0.1:9200/health"},
    "worker": {"type": "file", "path": "/home/pawelw/ctxproxy/worker/.worker.lock"},
}

# DB for metrics
DB_DSN = os.environ.get("CTXGATE_DB_DSN", "postgresql://postgres:11!!AdaMicPaw@127.0.0.1:5432/ctxproxy")

app = FastAPI(title="ctxgate-dashboard")

# Health state (updated by background poller)
health_state: dict = {
    "services": {},
    "db_metrics": {},
    "last_update": None,
}

# --- Controllable services (systemd units; override via env for AUR) ---
SVC_MAP = {
    "ctxgate_proxy": {
        "unit": os.environ.get("CTXGATE_SVC_PROXY", "ctxproxy-proxy.service"),
        "port": int(os.environ.get("CTXGATE_PROXY_PORT", "9200")),
        "health_url": os.environ.get("CTXGATE_PROXY_HEALTH", "http://127.0.0.1:9200/health"),
        "kind": "http",
    },
    "worker": {
        "unit": os.environ.get("CTXGATE_SVC_WORKER", "ctxproxy-worker.service"),
        "lock_path": os.environ.get("CTXGATE_WORKER_LOCK", "/home/pawelw/ctxproxy/worker/.worker.lock"),
        "kind": "file",
    },
}

# --- Health checkers ---
async def check_tcp(host: str, port: int, timeout: float = 2.0) -> dict:
    try:
        _, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port), timeout
        )
        writer.close()
        await writer.wait_closed()
        return {"status": "up", "latency_ms": None}
    except Exception as e:
        return {"status": "down", "error": str(e)[:100]}

async def check_http(url: str, timeout: float = 5.0) -> dict:
    start = time.time()
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            r = await client.get(url)
            latency = int((time.time() - start) * 1000)
            if r.status_code == 200:
                return {"status": "up", "latency_ms": latency}
            return {"status": "degraded", "latency_ms": latency, "http_code": r.status_code}
    except Exception as e:
        return {"status": "down", "error": str(e)[:100]}

async def check_worker_file(path: str) -> dict:
    try:
        with open(path, "r") as f:
            data = f.read()
        pid_match = re.search(r"pid=(\d+)", data)
        hb_match = re.search(r"heartbeat=([0-9.]+)", data)
        if not pid_match:
            return {"status": "down", "error": "no pid in lock file"}
        pid = int(pid_match.group(1))
        hb = float(hb_match.group(1)) if hb_match else 0
        age = time.time() - hb
        if age < 30:
            return {"status": "up", "pid": pid, "heartbeat_age_s": round(age, 1)}
        elif age < 120:
            return {"status": "degraded", "pid": pid, "heartbeat_age_s": round(age, 1), "error": "stale heartbeat"}
        else:
            return {"status": "down", "pid": pid, "heartbeat_age_s": round(age, 1), "error": "worker frozen/dead"}
    except FileNotFoundError:
        return {"status": "down", "error": "lock file not found"}
    except Exception as e:
        return {"status": "down", "error": str(e)[:100]}

async def get_db_metrics() -> dict:
    """Query PG for operational metrics."""
    try:
        import asyncpg
        conn = await asyncio.wait_for(asyncpg.connect(DB_DSN), timeout=5)
        try:
            tasks = await conn.fetchval("SELECT count(*) FROM proxy.tasks")
            events = await conn.fetchval("SELECT count(*) FROM proxy.events")
            memories = await conn.fetchval("SELECT count(*) FROM proxy.memories WHERE active=true")
            knowledge = await conn.fetchval("SELECT count(*) FROM proxy.knowledge WHERE active=true")
            jobs_pending = await conn.fetchval("SELECT count(*) FROM proxy.memory_jobs WHERE status='pending'")
            jobs_processing = await conn.fetchval("SELECT count(*) FROM proxy.memory_jobs WHERE status='processing'")
            jobs_done = await conn.fetchval("SELECT count(*) FROM proxy.memory_jobs WHERE status='done'")
            jobs_failed = await conn.fetchval("SELECT count(*) FROM proxy.memory_jobs WHERE status='failed'")
            return {
                "tasks": tasks, "events": events, "memories": memories,
                "knowledge": knowledge, "jobs_pending": jobs_pending,
                "jobs_processing": jobs_processing, "jobs_done": jobs_done,
                "jobs_failed": jobs_failed,
            }
        finally:
            await conn.close()
    except Exception as e:
        return {"error": str(e)[:100]}

# --- Process / port helpers (internal; user only touches the GUI) ---
async def _run(cmd: list, timeout: float = 60.0):
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        rc = proc.returncode if proc.returncode is not None else 0
        return (rc, out.decode().strip(), err.decode().strip())
    except FileNotFoundError:
        return (127, "", "command not found: " + cmd[0])
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except Exception:
            pass
        return (124, "", "timeout: " + cmd[0])

async def _systemctl(*args) -> tuple:
    return await _run(["systemctl", "--user"] + list(args))

async def _port_open(port: int) -> bool:
    try:
        _, writer = await asyncio.wait_for(asyncio.open_connection("127.0.0.1", port), timeout=2)
        writer.close()
        await writer.wait_closed()
        return True
    except Exception:
        return False

async def _port_pid(port: int) -> Optional[int]:
    rc, out, _ = await _run(["ss", "-tlnp", "sport = :" + str(port)])
    for line in out.splitlines():
        m = re.search(r"pid=(\d+)", line)
        if m:
            return int(m.group(1))
    return None

async def _kill_port_forever(port: int, max_wait: float = 30.0) -> tuple:
    """Force-free a port: find the listening PID, SIGKILL it, repeat until free."""
    steps = []
    deadline = time.time() + max_wait
    while time.time() < deadline:
        if not await _port_open(port):
            return True, steps
        pid = await _port_pid(port)
        if pid:
            try:
                os.kill(pid, signal.SIGKILL)
                steps.append("SIGKILL pid " + str(pid))
            except ProcessLookupError:
                steps.append("pid " + str(pid) + " already gone")
        else:
            steps.append("port open, no pid via ss")
        await asyncio.sleep(1.0)
    return (not await _port_open(port)), steps

async def _unit_main_pid(unit: str) -> int:
    rc, out, _ = await _systemctl("show", "-p", "MainPID", "--value", unit)
    return int(out) if out.isdigit() else 0

async def _wait_http(url: str, timeout: float = 20.0) -> tuple:
    deadline = time.time() + timeout
    last = "no response"
    while time.time() < deadline:
        try:
            async with httpx.AsyncClient(timeout=3) as client:
                r = await client.get(url)
            if r.status_code == 200:
                return True, "HTTP 200"
            last = "HTTP " + str(r.status_code)
        except Exception as e:
            last = str(e)[:60]
        await asyncio.sleep(1.0)
    return False, last

async def _wait_lock_fresh(path: str, timeout: float = 20.0) -> tuple:
    deadline = time.time() + timeout
    last = "lock file missing"
    while time.time() < deadline:
        try:
            with open(path) as f:
                data = f.read()
            m = re.search(r"heartbeat=([0-9.]+)", data)
            if m and (time.time() - float(m.group(1))) < 30:
                return True, "fresh heartbeat"
            last = "stale heartbeat"
        except FileNotFoundError:
            last = "lock file missing"
        except Exception as e:
            last = str(e)[:60]
        await asyncio.sleep(1.0)
    return False, last

# --- Control actions ---
async def _start(name: str) -> dict:
    cfg = SVC_MAP[name]
    steps = []
    if cfg["kind"] == "http" and await _port_open(cfg["port"]):
        rc, state, _ = await _systemctl("show", "-p", "ActiveState", "--value", cfg["unit"])
        if state != "active":
            ok, ksteps = await _kill_port_forever(cfg["port"])
            steps += ksteps
            if not ok:
                return {"ok": False, "error": "port " + str(cfg["port"]) + " still held", "steps": steps}
        else:
            steps.append("already running")
            return {"ok": True, "steps": steps}
    await _systemctl("reset-failed", cfg["unit"])
    rc, out, err = await _systemctl("start", cfg["unit"])
    steps.append("start rc=" + str(rc) + " " + (out or err).strip())
    if rc != 0:
        return {"ok": False, "error": "start failed: " + err, "steps": steps}
    if cfg["kind"] == "http":
        ok, detail = await _wait_http(cfg["health_url"])
    else:
        ok, detail = await _wait_lock_fresh(cfg["lock_path"])
    steps.append("verify: " + detail)
    return {"ok": ok, "steps": steps}

async def _stop(name: str) -> dict:
    cfg = SVC_MAP[name]
    steps = []
    rc, out, err = await _systemctl("stop", cfg["unit"])
    steps.append("stop rc=" + str(rc) + " " + (out or err).strip())
    pid = await _unit_main_pid(cfg["unit"])
    if pid:
        try:
            os.kill(pid, signal.SIGKILL)
            steps.append("SIGKILL leftover pid " + str(pid))
        except ProcessLookupError:
            steps.append("pid " + str(pid) + " already gone")
    if cfg["kind"] == "http":
        ok, ksteps = await _kill_port_forever(cfg["port"], max_wait=15.0)
        steps += ksteps
        steps.append("port " + str(cfg["port"]) + ": " + ("free" if ok else "STILL HELD"))
    else:
        try:
            os.remove(cfg["lock_path"])
            steps.append("removed lock file")
        except FileNotFoundError:
            steps.append("no lock file")
    return {"ok": True, "steps": steps}

async def _hard_restart(name: str) -> dict:
    """Kill forever + fresh start: the only way a stuck service ever recovers."""
    cfg = SVC_MAP[name]
    steps = []
    # 1. clean stop (SIGTERM; systemd escalates to SIGKILL on timeout)
    rc, out, err = await _systemctl("stop", cfg["unit"])
    steps.append("stop rc=" + str(rc) + " " + (out or err).strip())
    # 2. SIGKILL anything still alive
    pid = await _unit_main_pid(cfg["unit"])
    if pid:
        try:
            os.kill(pid, signal.SIGKILL)
            steps.append("SIGKILL pid " + str(pid))
        except ProcessLookupError:
            steps.append("pid " + str(pid) + " already gone")
    # 3. free the port (proxy) / remove the lock file (worker)
    if cfg["kind"] == "http":
        ok, ksteps = await _kill_port_forever(cfg["port"])
        steps += ksteps
        steps.append("port " + str(cfg["port"]) + ": " + ("free" if ok else "STILL HELD"))
        if not ok:
            return {"ok": False, "error": "port " + str(cfg["port"]) + " could not be freed", "steps": steps}
    else:
        try:
            os.remove(cfg["lock_path"])
            steps.append("removed stale lock file")
        except FileNotFoundError:
            steps.append("no lock file")
    # 4. reset start-limit counter (crash loops would otherwise block a fresh start)
    rc, out, err = await _systemctl("reset-failed", cfg["unit"])
    steps.append("reset-failed rc=" + str(rc))
    # 5. fresh start
    rc, out, err = await _systemctl("start", cfg["unit"])
    steps.append("start rc=" + str(rc) + " " + (out or err).strip())
    if rc != 0:
        return {"ok": False, "error": "fresh start failed: " + err, "steps": steps}
    # 6. verify it is actually healthy
    if cfg["kind"] == "http":
        ok, detail = await _wait_http(cfg["health_url"])
    else:
        ok, detail = await _wait_lock_fresh(cfg["lock_path"])
    steps.append("verify: " + detail)
    return {"ok": ok, "steps": steps}

# --- Background poller ---
async def poll_health():
    global health_state
    while True:
        services = {}
        for name, cfg in SERVICES.items():
            if cfg["type"] == "tcp":
                services[name] = await check_tcp(cfg["host"], cfg["port"])
            elif cfg["type"] == "http":
                services[name] = await check_http(cfg["url"])
            elif cfg["type"] == "file":
                services[name] = await check_worker_file(cfg["path"])
        db_metrics = await get_db_metrics()
        health_state = {
            "services": services,
            "db_metrics": db_metrics,
            "last_update": time.time(),
        }
        await asyncio.sleep(POLL_INTERVAL)

# --- Startup ---
@app.on_event("startup")
async def startup():
    asyncio.create_task(poll_health())

# --- Routes ---
@app.get("/health")
async def health():
    return {"status": "up", "port": PORT, "pid": os.getpid()}

@app.get("/api/health")
async def api_health():
    return JSONResponse(health_state)

@app.post("/api/control/{name}/{action}")
async def control(name: str, action: str):
    if name not in SVC_MAP:
        return JSONResponse({"ok": False, "error": "unknown service: " + name}, status_code=400)
    if action == "start":
        return JSONResponse(await _start(name))
    if action == "stop":
        return JSONResponse(await _stop(name))
    if action == "restart":
        return JSONResponse(await _hard_restart(name))
    return JSONResponse({"ok": False, "error": "unknown action: " + action}, status_code=400)

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    return DASHBOARD_HTML

# --- Dashboard HTML ---
DASHBOARD_HTML = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="refresh" content="10">
<title>ctxgate-dashboard</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Courier New', monospace; background: #0a0a0a; color: #e0e0e0; padding: 20px; }
h1 { color: #4af; margin-bottom: 20px; font-size: 1.4em; }
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 16px; }
.card { background: #1a1a2e; border: 1px solid #333; border-radius: 8px; padding: 16px; }
.card h3 { font-size: 0.9em; color: #888; margin-bottom: 8px; text-transform: uppercase; }
.status-up { color: #4f4; }
.status-down { color: #f44; }
.status-degraded { color: #fa0; }
.metric { display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid #222; gap: 8px; }
.metric:last-child { border-bottom: none; }
.metric .val { color: #4af; }
.btns { display: flex; gap: 4px; flex-shrink: 0; }
button { font-family: inherit; font-size: 0.75em; padding: 3px 8px; background: #111; color: #4f4; border: 1px solid #2a5a2a; border-radius: 4px; cursor: pointer; }
button:hover { background: #1d3a1d; }
button:disabled { color: #666; border-color: #333; cursor: wait; }
button.stop { color: #fa0; border-color: #5a4a1a; }
button.stop:hover { background: #3a2d1d; }
button.hard { color: #f44; border-color: #5a1a1a; }
button.hard:hover { background: #3a1d1d; }
button.hard.alert { background: #7a1a1a; color: #fff; font-weight: bold; }
.timestamp { color: #555; font-size: 0.8em; margin-top: 16px; }
.feedback { margin-top: 12px; padding: 10px; background: #111; border: 1px solid #333; border-radius: 6px; font-size: 0.8em; min-height: 1.2em; color: #4af; word-break: break-all; }
.legend { color: #666; font-size: 0.75em; margin-top: 8px; }
</style>
</head>
<body>
<h1>ctxgate-dashboard :9201</h1>
<div class="grid">
<div class="card">
<h3>Services</h3>
<div id="services"></div>
<div class="legend">green=up &middot; yellow=degraded &middot; red=down &middot; RESTART = kill forever + fresh start</div>
</div>
<div class="card">
<h3>Database Metrics</h3>
<div id="dbmetrics"></div>
</div>
</div>
<div class="feedback" id="feedback">control: all actions run from this GUI - no terminal needed</div>
<div class="timestamp" id="ts"></div>
<script>
var CONTROLLABLE = {'ctxgate_proxy': true, 'worker': true};
function render(d) {
    var svc = document.getElementById('services');
    svc.innerHTML = '';
    for (var key in (d.services || {})) {
        var name = key;
        var info = d.services[name];
        var cls = 'status-' + info.status;
        var dot = info.status === 'up' ? '🟢' : info.status === 'degraded' ? '🟡' : '🔴';
        var extra = '';
        if (info.latency_ms) extra = ' (' + info.latency_ms + 'ms)';
        if (info.heartbeat_age_s) extra = ' (hb ' + info.heartbeat_age_s + 's ago)';
        if (info.error) extra = ' - ' + info.error;
        var btns = '';
        if (CONTROLLABLE[name]) {
            var alert = info.status !== 'up' ? ' alert' : '';
            btns = '<span class="btns">'
                + '<button onclick="ctrl(\'' + name + '\','start',this)">START</button>'
                + '<button class="stop" onclick="ctrl(\'' + name + '\','stop',this)">STOP</button>'
                + '<button class="hard' + alert + '" onclick="ctrl(\'' + name + '\','restart',this)">RESTART</button>'
                + '</span>';
        }
        svc.innerHTML += '<div class="metric"><span>' + dot + ' ' + name + '</span>'
            + '<span class="' + cls + '">' + info.status + extra + '</span>' + btns + '</div>';
    }
    var db = document.getElementById('dbmetrics');
    db.innerHTML = '';
    if (d.db_metrics && !d.db_metrics.error) {
        for (var k in d.db_metrics) {
            db.innerHTML += '<div class="metric"><span>' + k + '</span><span class="val">' + d.db_metrics[k] + '</span></div>';
        }
    } else if (d.db_metrics && d.db_metrics.error) {
        db.innerHTML = '<div class="metric"><span>error</span><span class="status-down">' + d.db_metrics.error + '</span></div>';
    }
    document.getElementById('ts').textContent = 'Updated: ' + new Date(d.last_update * 1000).toLocaleString();
}
function ctrl(name, action, btn) {
    var fb = document.getElementById('feedback');
    var all = document.getElementsByTagName('button');
    for (var i = 0; i < all.length; i++) all[i].disabled = true;
    fb.textContent = name + ' ' + action + ' ... (running, page may refresh - the action continues server-side)';
    fetch('/api/control/' + name + '/' + action, {method: 'POST'})
        .then(function(r) { return r.json(); })
        .then(function(d) {
            fb.textContent = (d.ok ? 'OK: ' : 'FAIL: ') + (d.error || name + ' ' + action + ' done')
                + '  ||  ' + (d.steps || []).join('  ->  ');
            refresh();
        })
        .catch(function(e) {
            fb.textContent = 'ERROR: ' + e;
        })
        .finally(function() {
            var all2 = document.getElementsByTagName('button');
            for (var j = 0; j < all2.length; j++) all2[j].disabled = false;
        });
}
function refresh() {
    fetch('/api/health').then(function(r) { return r.json(); }).then(render).catch(function() {});
}
refresh();
</script>
</body>
</html>"""

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="info")

